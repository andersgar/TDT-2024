#include "std_lib_facilities.h"
#pragma once

double randomWithLimits(double upperLimit, double lowerLimit);